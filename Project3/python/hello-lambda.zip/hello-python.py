def lambda_handler(event, context):
    # Hello name program in python

    name = "AWS Lambda"

    message = 'Hello' + name
    return {
        'message' : message
    }