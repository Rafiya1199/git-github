def lambda_handler(event, context):
    x = "Hello World, Python is "
    y = "awesome"
    message = x + y
    return {
        'message' : message
    }
